# proposals

Docs Keeper ও Dev-agent এখানে পরিবর্তনের প্রস্তাব লেখে। কাস্টমার অনুমোদন দিলে তবেই `02-SSoT` বদলায়।
