# AGENTS.md — কোডিং এজেন্টের প্রবেশদ্বার

পড়ার ক্রম: `docs/12-Project-Brain/INDEX.md` → `docs/00-Foundation/mvp-scope.md` → `docs/20-Tasks/`।

## নিয়ম (বাধ্যতামূলক)
1. শুধু `status: confirmed` ফাইলের উপর ভিত্তি করে কোড লিখবে। `draft` হলে কাজ শুরুর আগে Docs Keeper-কে প্রশ্ন করবে।
2. `docs/`-এ নেই এমন ফিচার, লাইব্রেরি, API বা ডেটা-ফিল্ড নিজে থেকে যোগ করবে না।
3. `docs/` সরাসরি বদলাবে না। পরিবর্তন লাগলে `proposals/`-এ প্রস্তাব লিখবে।
4. `docs/20-Tasks/` থেকে একটা একটা করে TASK করবে। শেষে acceptance criteria মিলিয়ে দেখবে।
5. বিরোধ পেলে `02-SSoT/ssot.data.yaml` জিতবে।
6. জানা না থাকলে আন্দাজ নয়। `docs/11-Decisions/open-questions.yaml`-এ যোগ করো, `proposals/ESC-NNN.yaml` লিখে (ফরম্যাট: `agents/escalation-format.md`) থামো।
7. কোড শুধু `src/`-এ। কোডিং স্টাইল: `docs/10-Implementation/coding-standards.md`।

## Docs Keeper-কে জিজ্ঞেস করার ফরম্যাট
কাজের আগে `check(action)` চালাও। উত্তর: `ALLOWED | NOT_DOCUMENTED | CONFLICT | NEEDS_APPROVAL` + `evidence: [IDs]`।
evidence ছাড়া উত্তর গ্রহণযোগ্য নয়।

## এজেন্টের নির্দেশনা
তোমার নিজের সিস্টেম প্রম্পট: `agents/dev-agent.prompt.md`। প্রশ্ন করার জন্য Docs Keeper: `agents/docs-keeper.prompt.md`।
