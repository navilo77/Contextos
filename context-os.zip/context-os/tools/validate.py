#!/usr/bin/env python3
"""Docs Validator: schema, link, SSoT-sync ও Alignment Score যাচাই করে।

ব্যবহার:
    python tools/validate.py              # যাচাই + reports/report.md
    python tools/validate.py --package    # Gate পাস হলে dist/project.zip বানায়
"""
import sys
import re
import zipfile
import pathlib

try:
    import yaml
except ImportError:
    sys.exit("PyYAML দরকার: pip install pyyaml")

ROOT = pathlib.Path(__file__).resolve().parent.parent
DOCS = ROOT / "docs"
SKIP_DIRS = {"04-Schemas", "99-Templates"}
SPECIAL = {"ssot.data.yaml", "open-questions.yaml"}
ID_RE = re.compile(r"^([A-Z]+)-\d{3,}$")

# (নাম, ওজন, লক্ষ্য)
METRICS = [
    ("SSoT Sync", 25, 1.00),
    ("Traceability", 20, 0.95),
    ("Confirmation", 20, 0.90),
    ("Completeness", 15, 1.00),
    ("Consistency (AI)", 10, 1.00),
    ("Freshness", 10, 1.00),
]
PASS_SCORE = 90
WARN_SCORE = 70
LINK_KEYS = ("features", "api", "tests", "tasks")


def load_yaml(path):
    return yaml.safe_load(path.read_text(encoding="utf-8"))


def front(text):
    m = re.match(r"^---\n(.*?)\n---\n(.*)$", text, re.S)
    if not m:
        return None
    return yaml.safe_load(m.group(1)) or {}


def empty(v):
    return v is None or v == "" or v == []


def check_schema(rel, meta, schema, common, issues):
    required = list(common.get("required", [])) + list(schema.get("required", []))
    for f in required:
        if f == "links":
            if not isinstance(meta.get("links"), dict):
                issues.append(f"{rel}: links ফিল্ড নেই বা dict নয়")
        elif f not in meta or meta[f] is None or meta[f] == "":
            issues.append(f"{rel}: '{f}' ফিল্ড ফাঁকা বা নেই")
    enums = dict(common.get("enums", {}))
    enums.update(schema.get("enums", {}))
    for f, allowed in enums.items():
        if f in meta and meta[f] not in allowed:
            issues.append(f"{rel}: {f}='{meta[f]}' অনুমোদিত নয় {allowed}")
    for rule in common.get("rules", []):
        if all(meta.get(k) == v for k, v in rule["when"].items()):
            for f in rule["require"]:
                if empty(meta.get(f)):
                    issues.append(f"{rel}: {rule['when']} হলে '{f}' বাধ্যতামূলক")


def main():
    package = "--package" in sys.argv
    iss = {k: [] for k in ("schema", "duplicate", "broken", "draft",
                           "incomplete", "sync", "stale", "trace", "blocking", "must", "escalation")}

    manifest = load_yaml(ROOT / "manifest.yaml") or {}
    disabled = {k for k, v in (manifest.get("modules") or {}).items()
                if not (v or {}).get("enabled")}

    schemas = {}
    for p in (DOCS / "04-Schemas" / "schemas").glob("*.schema.yaml"):
        schemas[p.name] = load_yaml(p)
    common = schemas.pop("common.schema.yaml")
    by_prefix = {s["prefix"]: s for s in schemas.values() if "prefix" in s}

    ssot = load_yaml(DOCS / "02-SSoT" / "ssot.data.yaml") or {}
    index = ssot.get("index") or {}
    project_schema = schemas.get("project.schema.yaml") or {}
    spec_path = DOCS / "04-Schemas" / "file-specs.yaml"
    specs = (load_yaml(spec_path) or {}).get("files", {}) if spec_path.exists() else {}

    records, docs, skipped = {}, [], set()
    for p in sorted(DOCS.rglob("*")):
        if not p.is_file() or p.suffix not in (".md", ".yaml"):
            continue
        rel = p.relative_to(DOCS)
        parts = rel.parts
        if parts[0] in SKIP_DIRS or p.name in SPECIAL:
            continue
        if parts[0] in disabled:
            if p.suffix == ".yaml":
                d = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
                if isinstance(d, dict) and d.get("id"):
                    skipped.add(d["id"])
            continue
        text = p.read_text(encoding="utf-8")
        if p.suffix == ".md":
            meta = front(text)
            if meta is None:
                iss["schema"].append(f"{rel}: frontmatter (---) নেই")
                continue
            if meta.get("status") == "confirmed" and empty(meta.get("approved_by")):
                iss["schema"].append(f"{rel}: confirmed হলে approved_by বাধ্যতামূলক")
            need = specs.get(rel.as_posix())
            if need and meta.get("status") != "not-applicable" and meta.get("applicable") is not False:
                found = set(re.findall(r"^## (.+?)\s*$", text, re.M))
                for h in need:
                    if h not in found:
                        iss["schema"].append(f"{rel}: নির্ধারিত অংশ '## {h}' নেই")
        else:
            data = yaml.safe_load(text) or {}
            meta = data if isinstance(data, dict) else {}
            m = ID_RE.match(str(meta.get("id", "")))
            if m and m.group(1) in by_prefix:
                rid = meta["id"]
                if rid in records:
                    iss["duplicate"].append(f"{rid}: {rel} ও {records[rid][0]}")
                records[rid] = (rel, meta)
                if ID_RE.match(p.stem) and p.stem != rid:
                    iss["schema"].append(f"{rel}: ফাইলের নাম ({p.stem}) ও id ({rid}) মেলে না")
                check_schema(rel, meta, by_prefix[m.group(1)], common, iss["schema"])
        docs.append((rel, meta, text))

    # প্রযোজ্য ডকুমেন্ট, draft, completeness
    applicable = []
    for rel, meta, text in docs:
        if meta.get("status") == "not-applicable" or meta.get("applicable") is False:
            if empty(meta.get("reason")):
                iss["incomplete"].append(f"{rel}: not-applicable-এ 'reason' নেই")
            continue
        applicable.append((rel, meta, text))
    confirmed = complete = 0
    for rel, meta, text in applicable:
        if meta.get("status") == "confirmed":
            confirmed += 1
        else:
            iss["draft"].append(f"{rel}: status={meta.get('status', '?')}")
        if "TODO" in text:
            iss["incomplete"].append(f"{rel}: TODO বাকি")
        else:
            complete += 1

    # ডুপ্লিকেট title (একই ধরনের রেকর্ডে)
    seen_titles = {}
    for rid, (rel, meta) in records.items():
        key = (rid.split("-")[0], str(meta.get("title", "")).strip().lower())
        if key in seen_titles:
            iss["duplicate"].append(f"{rid} ও {seen_titles[key]}: একই title")
        seen_titles[key] = rid

    # depends_on / applies_to-র ID আছে কি না, আর TASK-এ চক্র
    for rid, (rel, meta) in records.items():
        for key in ("depends_on", "applies_to"):
            for t in meta.get(key) or []:
                if ID_RE.match(str(t)) and t not in records:
                    iss["broken"].append(f"{rid} ({rel}) → {t} পাওয়া যায়নি [{key}]")
    graph = {r: list((m.get("depends_on") or [])) for r, (_, m) in records.items() if r.startswith("TASK-")}
    state = {}

    def visit(n, path):
        if state.get(n) == 2 or n not in graph:
            return
        if state.get(n) == 1:
            iss["broken"].append("TASK-এ চক্র: " + " → ".join(path + [n]))
            return
        state[n] = 1
        for d in graph[n]:
            visit(d, path + [n])
        state[n] = 2

    for n in graph:
        visit(n, [])

    # ভাঙা লিংক
    for rid, (rel, meta) in records.items():
        for key, ids in (meta.get("links") or {}).items():
            for t in ids or []:
                if t not in records:
                    iss["broken"].append(f"{rid} ({rel}) → {t} পাওয়া যায়নি [{key}]")

    # SSoT sync + freshness
    all_ids = (set(records) | set(index)) - skipped
    sync_ok = 0
    stale = 0
    for rid in sorted(all_ids):
        entry = index.get(rid)
        if rid not in records:
            iss["sync"].append(f"{rid}: ssot-এ আছে, কিন্তু ফাইল নেই")
            continue
        rel, meta = records[rid]
        if entry is None:
            iss["sync"].append(f"{rid}: ফাইল আছে, ssot index-এ নেই")
            continue
        diff = [k for k in ("title", "status", "source") if entry.get(k) != meta.get(k)]
        if diff:
            iss["sync"].append(f"{rid}: ssot-এর সাথে মিলছে না → {', '.join(diff)}")
        else:
            sync_ok += 1
        if str(entry.get("updated", "")) > str(meta.get("updated", "")):
            stale += 1
            iss["stale"].append(f"{rid}: ssot নতুন, ফাইল পুরনো")

    # Traceability (শুধু REQ)
    reqs = {k: v for k, v in records.items() if k.startswith("REQ-")}
    trace_ok = 0
    for rid, (rel, meta) in reqs.items():
        links = meta.get("links") or {}
        missing = [k for k in LINK_KEYS if empty(links.get(k))]
        if missing:
            iss["trace"].append(f"{rid}: লিংক নেই → {', '.join(missing)}")
        else:
            trace_ok += 1

    # must-have REQ সব confirmed হতে হবে
    for rid, (rel, meta) in reqs.items():
        if meta.get("priority") == "must" and meta.get("status") not in ("confirmed", "not-applicable"):
            iss["must"].append(f"{rid}: priority=must কিন্তু status={meta.get('status')}")

    # খোলা blocking প্রশ্ন
    oq = load_yaml(DOCS / "11-Decisions" / "open-questions.yaml") or {}
    seen_q = set()
    for q in oq.get("questions") or []:
        miss = [f for f in ("id", "question", "blocking", "status") if f not in q]
        if miss:
            iss["schema"].append(f"open-questions.yaml: {q.get('id', '?')} ফিল্ড নেই → {', '.join(miss)}")
        if q.get("id") in seen_q:
            iss["duplicate"].append(f"open-questions.yaml: {q.get('id')} ডুপ্লিকেট")
        seen_q.add(q.get("id"))
        if q.get("status") not in ("open", "closed"):
            iss["schema"].append(f"open-questions.yaml: {q.get('id')} status 'open' বা 'closed' হতে হবে")
        if q.get("status") == "open" and q.get("blocking"):
            iss["blocking"].append(f"{q.get('id')}: {q.get('question')}")

    # খোলা escalation
    for ep in sorted((ROOT / "proposals").glob("ESC-*.yaml")):
        e = load_yaml(ep) or {}
        if e.get("status") != "closed":
            iss["escalation"].append(f"{ep.name}: {e.get('type', '?')}: {e.get('what_is_missing', '')}")

    # AI consistency রিপোর্ট
    ai_path = ROOT / "reports" / "ai-consistency.yaml"
    ai = load_yaml(ai_path) if ai_path.exists() else None
    ai_done = bool(ai) and bool(ai.get("checked")) and isinstance(ai.get("high_conflicts"), int)

    # প্রজেক্টের নাম/ধরন ভরা কি না
    proj_ok = True
    if re.search(r"project_(name|type):\s*TODO", (ROOT / "manifest.yaml").read_text(encoding="utf-8")):
        iss["incomplete"].append("manifest.yaml: project_name/project_type ভরা হয়নি")
        proj_ok = False
    for f in project_schema.get("required", []):
        if empty((ssot.get("project") or {}).get(f)):
            iss["incomplete"].append(f"ssot.data.yaml: project.{f} ফাঁকা")
            proj_ok = False
    if "TODO" in str(ssot.get("project")):
        iss["incomplete"].append("ssot.data.yaml: project name/type ভরা হয়নি")
        proj_ok = False

    rates = {
        "SSoT Sync": sync_ok / len(all_ids) if all_ids else 0,
        "Traceability": trace_ok / len(reqs) if reqs else 0,
        "Confirmation": confirmed / len(applicable) if applicable else 0,
        "Completeness": complete / len(applicable) if applicable else 0,
        "Consistency (AI)": 1.0 if ai_done and ai["high_conflicts"] == 0 else 0.0,
        "Freshness": 1 - stale / len(records) if records else 0,
    }
    rows, score = [], 0.0
    for name, weight, target in METRICS:
        pts = min(rates[name] / target, 1.0) * weight
        score += pts
        rows.append((name, rates[name], target, weight, pts))

    hard = [
        ("schema ত্রুটি = 0", not iss["schema"]),
        ("ডুপ্লিকেট ID = 0", not iss["duplicate"]),
        ("ভাঙা লিংক = 0", not iss["broken"]),
        ("SSoT Sync = 100%", rates["SSoT Sync"] == 1.0),
        ("পুরনো (stale) ফাইল = 0", not iss["stale"]),
        ("অসম্পূর্ণ (TODO) ফাইল = 0", not iss["incomplete"]),
        ("সব must-have REQ confirmed", not iss["must"]),
        ("খোলা blocking প্রশ্ন = 0", not iss["blocking"]),
        ("খোলা escalation (proposals/ESC-*) = 0", not iss["escalation"]),
        ("AI consistency যাচাই সম্পন্ন (checked তারিখ আছে)", ai_done),
        ("AI-ধরা high বিরোধ = 0", ai_done and ai["high_conflicts"] == 0),
        ("manifest ও ssot-এ প্রজেক্টের নাম/ধরন ভরা", proj_ok),
        (f"স্কোর ≥ {PASS_SCORE}", score >= PASS_SCORE),
    ]
    gate = all(ok for _, ok in hard)
    state = "🟢" if score >= PASS_SCORE else ("🟡" if score >= WARN_SCORE else "🔴")

    out = [f"# Validation Report\n", f"**স্কোর: {score:.1f} / 100 {state}**  |  "
           f"**Gate: {'✅ PASS' if gate else '⛔ BLOCKED'}**\n",
           "## মাপকাঠি\n", "| মাপকাঠি | অর্জন | লক্ষ্য | ওজন | পয়েন্ট |", "|---|---|---|---|---|"]
    for name, rate, target, weight, pts in rows:
        out.append(f"| {name} | {rate:.0%} | {target:.0%} | {weight} | {pts:.1f} |")
    out += ["", "## Gate শর্ত\n"]
    out += [f"- {'✅' if ok else '❌'} {label}" for label, ok in hard]
    titles = {"schema": "Schema ত্রুটি", "duplicate": "ডুপ্লিকেট ID", "broken": "ভাঙা লিংক",
              "blocking": "খোলা blocking প্রশ্ন", "sync": "SSoT Sync সমস্যা",
              "stale": "পুরনো ফাইল", "trace": "Traceability ফাঁক",
              "draft": "এখনো confirmed নয়", "incomplete": "অসম্পূর্ণ (TODO)",
              "must": "must-have REQ confirmed নয়", "escalation": "খোলা escalation"}
    for key, title in titles.items():
        if iss[key]:
            out += ["", f"## {title} ({len(iss[key])})\n"]
            out += [f"- {x}" for x in iss[key][:50]]
            if len(iss[key]) > 50:
                out.append(f"- … আরও {len(iss[key]) - 50}টি")
    rep = ROOT / "reports"
    rep.mkdir(exist_ok=True)
    (rep / "report.md").write_text("\n".join(out) + "\n", encoding="utf-8")

    print(f"স্কোর {score:.1f}/100 {state} | Gate: {'PASS' if gate else 'BLOCKED'}")
    for label, ok in hard:
        print(f"  {'OK ' if ok else 'XX '} {label}")
    print("বিস্তারিত: reports/report.md")

    if package:
        if not gate:
            print("Gate পাস হয়নি, zip বানানো হলো না।")
            return 1
        dist = ROOT / "dist"
        dist.mkdir(exist_ok=True)
        target = dist / "project.zip"
        with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as z:
            for p in sorted(ROOT.rglob("*")):
                rp = p.relative_to(ROOT)
                if p.is_dir() or rp.parts[0] in ("dist", ".git") or "__pycache__" in rp.parts:
                    continue
                z.write(p, rp)
        print(f"তৈরি: {target}")
    return 0 if gate else 1


if __name__ == "__main__":
    sys.exit(main())
