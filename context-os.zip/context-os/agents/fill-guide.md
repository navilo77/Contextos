# Fill Guide: কোন ফোল্ডার কে ভরবে, "শেষ" মানে কী

| ফোল্ডার | কে ভরে | source | "শেষ" যখন |
|---|---|---|---|
| `00-Foundation` | কাস্টমার থেকে নিয়ে Context-Engineer | customer | ভিশন, MVP, non-goals কাস্টমার অনুমোদন করেছে |
| `01-Governance` | Context-Engineer খসড়া, কাস্টমার অনুমোদন | agent-assumed → confirmed | কে কী অনুমোদন করে লেখা, change-control মানা হচ্ছে |
| `02-SSoT` | Context-Engineer / Keeper | — | প্রতিটা ID-র `index` ফাইলের সাথে হুবহু মেলে |
| `03-Agent-Contracts` | Context-Engineer খসড়া | agent-assumed | `reads`, `writes`, `forbidden`, `escalate_when` ভরা |
| `19-Customer-Voice` | কাস্টমারের কথা | customer | likes, dislikes, references, must_not ভরা; log-এ হুবহু উত্তর |
| `05-PRD` | কাস্টমার থেকে | customer | প্রতিটা REQ-এ priority ও মাপার মতো acceptance criteria; লিংক ঠিক |
| `06-SAD` / `07-Database` / `08-API` | এজেন্ট খসড়া, কাস্টমার গুরুত্বপূর্ণ অংশে অনুমোদন | agent-assumed → confirmed | প্রতিটা REQ-এর জন্য API/ডেটা আছে, নাম ও ধরন মেলে |
| `09-Validation` | এজেন্ট | agent-assumed | প্রতিটা REQ-এর কমপক্ষে একটা EVAL |
| `10-Implementation` | এজেন্ট | agent-assumed | স্টাইল, ফোল্ডার, env-নাম লেখা |
| `11-Decisions` | সবাই (Keeper প্রয়োগ করে) | customer | প্রতিটা চূড়ান্ত সিদ্ধান্তের DEC, `blocking` প্রশ্ন ০ |
| `20-Tasks` | Context-Engineer | agent-assumed | ছোট (একটা কাজ), ক্রমানুসারে, `done_when` মাপার মতো |
| `13`–`18` (মডিউল) | এজেন্ট খসড়া | agent-assumed | `manifest.yaml`-এ চালু হলে সব ফাইল ভরা; না লাগা ফাইলে `not-applicable` + কারণ |

## সাধারণ ভুল (এড়াও)
- খসড়াকে `confirmed` বা `customer` বলা
- acceptance criteria-তে "দ্রুত", "সুন্দর" লেখা। সংখ্যা বা পরীক্ষাযোগ্য শর্ত লেখো
- একই তথ্য দুই ফাইলে কপি করা। এক জায়গায় রাখো, বাকিতে ID দাও
- ssot আপডেট না করে ফাইল বদলানো (Sync ভাঙে)
- ফাঁকা বা TODO রেখে ফাইল ছেড়ে দেওয়া। দরকার না হলে `not-applicable` + কারণ
- বড় TASK। একটা TASK একবসায় শেষ করার মতো ছোট রাখো

## একটা রেকর্ড কখন ভালো
1. কাস্টমারের কোন কথা থেকে এসেছে, `evidence` দেখায়
2. মাপা যায় (পরীক্ষা লেখা যায়)
3. অন্য রেকর্ডের সাথে লিংক আছে
4. ssot index-এর সাথে মেলে
5. `approved_by` আছে (confirmed হলে)
