# agents/

এজেন্টদের সিস্টেম প্রম্পট ও গাইড। এগুলো প্রজেক্টের ডকুমেন্ট নয়, এজেন্টের নির্দেশনা।

| ফাইল | কে পড়বে | কাজ |
|---|---|---|
| `context-engineer.prompt.md` | Context-Engineer এজেন্ট | কাস্টমারের সাথে কথা বলে docs ভরা |
| `docs-keeper.prompt.md` | Docs Keeper এজেন্ট | docs রক্ষা, যাচাই, অনুমোদিত পরিবর্তন প্রয়োগ |
| `dev-agent.prompt.md` | কোডিং এজেন্ট | TASK অনুযায়ী কোড লেখা |
| `build-readiness-tester.prompt.md` | Tester এজেন্ট | প্যাকেজ থেকে অ্যাপ বানানো যাবে কি না, স্কোরসহ রিপোর্ট |
| `build-readiness-report.template.yaml` | Tester | রিপোর্টের ছাঁচ |
| `escalation-format.md` | সব এজেন্ট | আটকে গেলে কীভাবে জানাবে (ESC ফাইল) |
| `interview-guide.md` | Context-Engineer | কাস্টমারকে কোন প্রশ্ন কোন ক্রমে |
| `fill-guide.md` | Context-Engineer ও Keeper | কোন ফোল্ডার কে ভরবে, "শেষ" মানে কী |

প্রতিটা এজেন্টকে তার প্রম্পট সিস্টেম প্রম্পট হিসেবে দাও, আর `docs/` ফোল্ডার tool/file-access হিসেবে দাও।
