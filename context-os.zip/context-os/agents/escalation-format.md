# Escalation ফরম্যাট

আটকে গেলে (docs-এ উত্তর নেই, বিরোধ, অস্পষ্ট TASK) আন্দাজ না করে `proposals/ESC-NNN.yaml` লেখো এবং **থামো**।

```yaml
id: ESC-001
raised_by: dev-agent | context-engineer | docs-keeper | tester
raised_on: 2026-10-28
status: open            # open | closed
type: NOT_DOCUMENTED | CONFLICT | NEEDS_APPROVAL | BLOCKED
task: TASK-005          # আটকে থাকা কাজ (থাকলে)
evidence: [REQ-004, API-003]     # যে রেকর্ডগুলো দেখেছো
what_is_missing: "ঠিক কী জানা নেই বা কোথায় বিরোধ"
options_considered: []  # সম্ভাব্য বিকল্প। কোনটা বেছে নিও না
blocking: true          # না থামলে কাজ এগোবে না
question_for_customer: "সাধারণ ভাষায় একটা প্রশ্ন"
resolution: null        # Docs Keeper সমাধানের পর ভরবে
resolved_by: null
```

**Docs Keeper-এর কাজ:** ESC পেলে (১) `open-questions.yaml`-এ প্রশ্ন যোগ করো (`blocking` মিলিয়ে), (২) কাস্টমারের উত্তর/অনুমোদন পেলে `proposals/`-এর নিয়মে docs বদলাও, (৩) ESC-তে `resolution`, `resolved_by` ভরে `status: closed`।
**নিয়ম:** `status: open` ESC থাকলে validator-এর Gate আটকে থাকে।
