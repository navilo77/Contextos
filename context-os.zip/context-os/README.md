# Context OS

**Context OS**: একটা নির্দিষ্ট টেমপ্লেট-কাঠামো, যার মধ্য দিয়ে এজেন্ট পুরো প্রজেক্ট ভুলহীনভাবে বানাতে পারে। কাস্টমারের ভিশন থেকে কোডিং এজেন্টের হাতে তুলে দেওয়ার জন্য।

## ব্যবহার
1. `manifest.yaml` ভরো, দরকার নেই এমন মডিউল বন্ধ করো।
2. Context-Engineer এজেন্ট কাস্টমারকে প্রশ্ন করে `00`, `05`, `19` ভরবে।
3. বাকি ফোল্ডার এজেন্ট খসড়া করবে (`source: agent-assumed`), কাস্টমার অনুমোদন দিলে `confirmed`।
4. `python tools/validate.py` চালিয়ে `reports/report.md` দেখো।
5. Gate পাস হলে `python tools/validate.py --package` দিয়ে `dist/project.zip` বানাও।

এজেন্টদের সিস্টেম প্রম্পট ও গাইড: `agents/`।

প্রথমে যাচাই চালালে স্কোর কম আসবে। এটাই স্বাভাবিক, কারণ সব এখনো TODO।
`docs/` ভেতরের নিয়ম: `docs/04-Schemas/YAML-SCHEMA-SPEC.md`।

## বানানোর যোগ্যতা পরীক্ষা (Gate-এর আগে বা পরে)
Tester এজেন্টকে `agents/build-readiness-tester.prompt.md` দাও। সে `reports/build-readiness.md` ও `.yaml`-এ ১০০-এর মধ্যে স্কোর, ফাঁকের তালিকা ও কী ঠিক করলে স্কোর বাড়বে তা দেবে। `build-test/` তার খসড়া জায়গা।

## কমান্ড
```
make check      # যাচাই + স্কোর (reports/report.md)
make package    # Gate পাস হলে dist/project.zip
```

## manifest.yaml কী করে
`manifest.yaml` শুধু **ঐচ্ছিক মডিউল ফোল্ডার** (`13`–`18`) চালু বা বন্ধ করে। মূল ফোল্ডার (`00`–`12`, `19`, `20`) সবসময় প্রযোজ্য, তাই সেগুলো manifest-এ লেখা হয় না।

## প্রতিটা ফাইলে কী লিখতে হবে
`docs/04-Schemas/file-specs.yaml` প্রতিটা `.md` ফাইলের জন্য নির্ধারিত `## ` অংশ বলে দেয়। validator সেগুলো আছে কি না যাচাই করে। কোনো ফাইল প্রযোজ্য না হলে `status: not-applicable` ও `reason` দাও।

## আটকে গেলে
`agents/escalation-format.md` অনুযায়ী `proposals/ESC-NNN.yaml`। খোলা ESC থাকলে Gate আটকে থাকে।

## প্রথমবার
`make setup` (PyYAML ইনস্টল), তারপর `make check`।
