---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# Sales Metrics

> বিক্রির সংখ্যা ও মাপকাঠি।

## Metric definitions

> টেবিল: নাম | সূত্র | ডেটার উৎস | লক্ষ্য।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Refresh frequency

> কত ঘন ঘন হালনাগাদ।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Owner

> কে দেখে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Alert threshold

> কখন সতর্কতা।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

