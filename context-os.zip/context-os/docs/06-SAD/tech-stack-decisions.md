---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# Tech Stack Decisions

> ভাষা, ফ্রেমওয়ার্ক, ডাটাবেস, হোস্টিং। কাস্টমারের অনুমোদন দরকার।

## Languages and frameworks

> কোনটা, ভার্সনসহ, কেন।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Database

> কোন ডাটাবেস ও কেন।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Hosting

> কোথায় চলবে, খরচের সীমা।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Libraries allowed and forbidden

> কোন লাইব্রেরি চলবে, কোনটা চলবে না।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Decision links

> সংশ্লিষ্ট DEC ID; কাস্টমারের অনুমোদন।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

