---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# Frontend State & Architecture

> ফ্রন্টএন্ডের state ও ডেটা-আনার সিদ্ধান্ত, যাতে এজেন্ট নিজে বেছে না নেয়। (এজেন্ট-যোগ করা ফাইল)

## Rendering approach

> SPA/SSR/স্ট্যাটিক, কেন।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## State management

> কোন টুল (Context, Redux, Zustand ইত্যাদি) ও কেন, কোন state কোথায় থাকবে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Data fetching and caching

> সার্ভার থেকে ডেটা আনা ও ক্যাশের নিয়ম।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Routing

> পেজ ও URL-এর তালিকা, সুরক্ষিত পেজ।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Forms and validation

> ফর্ম বিধি, ত্রুটির প্রদর্শন।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Error and offline states

> নেটওয়ার্ক ফেল বা অফলাইনে কী হবে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

