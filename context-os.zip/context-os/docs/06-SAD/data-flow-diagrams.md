---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# Data Flow Diagrams

> ডেটা কোথা থেকে কোথায় যায়।

## Main flows

> ডেটা কোথা থেকে কোথায় যায় (টেক্সট বা mermaid)।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Data stores

> কোন ডেটা কোথায় রাখা হয়।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## External systems

> বাইরের কোন সার্ভিসের সাথে লেনদেন।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Sensitive data paths

> ব্যক্তিগত/আর্থিক তথ্য কোন পথে যায়।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

