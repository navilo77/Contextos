---
status: draft
source: customer
applicable: true
updated: 2026-10-28
---
# MVP Scope

> প্রথম সংস্করণে কী থাকবে, কোন REQ/FEAT।

## In scope

> MVP-তে কোন REQ/FEAT (ID দিয়ে)।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Out of scope

> MVP-তে থাকছে না, কেন।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Release criteria

> কী হলে MVP 'শেষ': পরিমাপযোগ্য শর্ত।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Deadline and budget

> সময়সীমা ও বাজেট, যা কাস্টমার বলেছে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

