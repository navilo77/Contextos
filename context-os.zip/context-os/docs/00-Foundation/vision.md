---
status: draft
source: customer
applicable: true
updated: 2026-10-28
---
# Vision

> প্রজেক্ট কেন, কার জন্য, সফলতা কীভাবে মাপা হবে।

## Problem

> কোন সমস্যা সমাধান হবে? কাস্টমারের নিজের কথায়।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Target users

> কারা ব্যবহার করবে? (personas.md-এর লিংক)

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Desired outcome

> সফল হলে কী বদলাবে?

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Success measures

> সংখ্যায় মাপার উপায়: কী, কত, কত সময়ে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Evidence

> interview-log.md-এর কোন লাইন থেকে এসেছে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

