---
status: draft
source: customer
applicable: true
updated: 2026-10-28
---
# Non-Goals

> যা এখন বানানো হবে না, কারণসহ।

## Not building

> যা বানানো হবে না (তালিকা)।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Reason

> প্রতিটার কারণ।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Revisit when

> কখন আবার ভাবা হবে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

