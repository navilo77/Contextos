---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# Glossary

> প্রজেক্টের বিশেষ শব্দের একটাই সংজ্ঞা।

## Terms

> টেবিল: শব্দ | অর্থ | যার সাথে গুলিয়ে ফেলা যাবে না। প্রতিটা শব্দের একটাই অর্থ।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

