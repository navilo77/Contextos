---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# SSoT Summary

> মানুষের পড়ার সারাংশ। এটা মূল উৎস নয়, `ssot.data.yaml` মূল।

## Project summary

> প্রজেক্ট এক অনুচ্ছেদে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Key decisions

> গুরুত্বপূর্ণ DEC-গুলোর সারাংশ।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Open risks

> জানা ঝুঁকি ও খোলা প্রশ্ন।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

