---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# AI Agent Workflow

> AI এজেন্টের কাজের পুরো ধারা।

## Steps

> AI-এর কাজের ধারা।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Tools allowed

> কোন টুল ব্যবহার করতে পারবে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Memory and context

> কী মনে রাখবে, কতক্ষণ।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Cost and latency limits

> খরচ ও সময়ের সীমা।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Logging

> কী লগ হবে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

