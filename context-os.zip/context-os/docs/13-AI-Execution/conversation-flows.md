---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# Conversation Flows

> কথোপকথনের ধাপ ও শাখা।

## Entry points

> কথোপকথন কোথা থেকে শুরু।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Intents

> ব্যবহারকারী কী কী চাইতে পারে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Flow per intent

> প্রতিটার ধাপ।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Dead-ends and recovery

> বুঝতে না পারলে কী করবে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Tone and language

> কণ্ঠস্বর ও ভাষা।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

