---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# Hallucination Guardrails

> AI কী বলতে পারবে না, কীভাবে আটকানো হবে।

## Allowed knowledge sources

> AI কোথা থেকে তথ্য নিয়ে উত্তর দিতে পারবে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Forbidden claims

> যা AI কখনো বলতে পারবে না (দাম বানানো, প্রতিশ্রুতি, চিকিৎসা পরামর্শ ইত্যাদি)।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Fallback phrasing

> উত্তর জানা না থাকলে হুবহু কী বলবে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Verification before answering

> উত্তরের আগে কী যাচাই করবে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Refusal examples

> কয়েকটা উদাহরণ।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

