---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# Escalation Rules

> কখন মানুষের কাছে হস্তান্তর।

## Triggers

> কোন অবস্থায় মানুষের কাছে হস্তান্তর।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Handover

> কোন চ্যানেলে, কী তথ্যসহ।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Response time

> মানুষ কত সময়ে সাড়া দেবে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## After handover

> হস্তান্তরের পর AI কী করবে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

