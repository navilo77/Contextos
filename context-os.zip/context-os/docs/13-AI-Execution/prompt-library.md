---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# Prompt Library

> প্রোডাক্টের ভেতরের AI-এর prompt সংগ্রহ।

## Prompts

> টেবিল: id | উদ্দেশ্য | ভার্সন।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Variables

> প্রতিটা prompt-এর ভেরিয়েবল।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Test cases

> প্রতিটা prompt-এর প্রত্যাশিত উত্তরের উদাহরণ।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

