---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# Roles & Approval

> কে কী অনুমোদন করে। কাস্টমার, Keeper, Dev-agent-এর অধিকার।

## Roles

> কাস্টমার, Context-Engineer, Docs Keeper, Dev-agent, পর্যালোচক: কে কী।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Who approves what

> কোন সিদ্ধান্ত কে অনুমোদন করে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Approval evidence

> অনুমোদনের প্রমাণ কেমন (নাম, তারিখ, কোথায় লেখা)।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Escalation owner

> আটকে গেলে কে সিদ্ধান্ত নেয়।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

