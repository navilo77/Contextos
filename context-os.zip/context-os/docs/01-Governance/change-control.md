---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# Change Control

> পরিবর্তনের প্রস্তাব → অনুমোদন → ssot আপডেট → আবার Validate।

## Change types

> ছোট বদল, নতুন ফিচার, বাতিল: কোনটার কী নিয়ম।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Process

> প্রস্তাব → অনুমোদন → ssot → ফাইল → validate।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Impact check

> বদলালে কোন REQ/API/TASK/EVAL প্রভাবিত, তা দেখার নিয়ম।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Versioning

> পরিবর্তনের ইতিহাস কোথায় (DEC রেকর্ড)।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

