---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# Webhook Handling

> বাইরের সার্ভিসের webhook-এর নিরাপত্তা ও পুনঃচেষ্টা। (এজেন্ট-যোগ করা ফাইল)

## Endpoints

> কোন webhook URL কোন সার্ভিসের জন্য।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Signature verification

> সত্যতা যাচাই।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Idempotency and duplicates

> একই ঘটনা দুবার এলে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Retries and ordering

> ক্রম ভাঙলে বা দেরিতে এলে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Failure storage

> প্রক্রিয়া ব্যর্থ হলে কোথায় রাখা হবে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Testing

> replay বা নকল ইভেন্ট দিয়ে পরীক্ষা।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

