---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# Local Setup

> নিজের কম্পিউটারে প্রজেক্ট চালু করার ধাপ। (এজেন্ট-যোগ করা ফাইল)

## Prerequisites

> দরকারি সফটওয়্যার ও ভার্সন।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Install

> ধাপে ধাপে কমান্ড (ডকার সহ ও ছাড়া)।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Run

> অ্যাপ চালানোর কমান্ড ও পোর্ট।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Test

> টেস্ট চালানোর কমান্ড।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Common errors

> চেনা সমস্যা ও সমাধান।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

