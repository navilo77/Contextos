---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# Coding Standards

> নামকরণ, ফরম্যাটিং, কী করা যাবে না।

## Naming

> ফাইল, ফাংশন, ভেরিয়েবলের নাম।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Formatting and linter

> কোন টুল, কী নিয়ম।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Folder rules

> কোথায় কী যাবে (repo-structure.md)।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Error handling

> ত্রুটি কীভাবে ধরা ও দেখানো হবে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Comments and docs

> কখন মন্তব্য লিখতে হবে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Forbidden practices

> কী করা যাবে না।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

