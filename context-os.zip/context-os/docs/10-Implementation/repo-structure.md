---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# Repo Structure

> `src/`-এর ভেতরের ফোল্ডার কাঠামো।

## Tree

> src/-এর ফোল্ডার কাঠামো।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Module boundaries

> কোন মডিউল কার উপর নির্ভর করতে পারে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Tests location

> টেস্ট কোথায় থাকবে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Config files

> কনফিগ ফাইলের তালিকা।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

