---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# i18n & Localization

> ভাষা ও বার্তা সংরক্ষণের নিয়ম। (এজেন্ট-যোগ করা ফাইল)

## Supported languages

> কোন কোন ভাষা (যেমন বাংলা, ইংরেজি)।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Default language

> ডিফল্ট ও ব্যবহারকারী কীভাবে বদলাবে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Text storage

> বার্তা কোন ফাইল/ফরম্যাটে, key-র নিয়ম।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Translation workflow

> নতুন বার্তা কে অনুবাদ ও অনুমোদন করে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Formats

> তারিখ, সংখ্যা, মুদ্রা (বাংলা অঙ্ক চলবে কি না)।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Fonts and rendering

> বাংলা ফন্ট ও টেক্সট রেন্ডারিংয়ের নোট।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

