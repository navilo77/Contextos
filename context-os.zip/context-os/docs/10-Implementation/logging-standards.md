---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# Logging Standards

> কোডের ভেতরের লগের স্তর ও ফরম্যাট। (এজেন্ট-যোগ করা ফাইল)

## Log levels

> debug, info, warn, error: কখন কোনটা।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Format

> লগের ক্ষেত্র (সময়, স্তর, বার্তা, request-id ইত্যাদি)।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Never log

> যা লগে যাবে না (পাসওয়ার্ড, টোকেন, ব্যক্তিগত তথ্য)।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Retention

> কত দিন রাখা হবে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Correlation IDs

> একটা অনুরোধ জুড়ে ট্র্যাক করার নিয়ম।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

