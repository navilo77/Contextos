---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# Env & Config

> Environment variable-এর নাম ও ব্যাখ্যা। মান বা secret এখানে নয়।

## Variables

> টেবিল: নাম | উদ্দেশ্য | মানের ধরন | বাধ্যতামূলক? | secret? (মান লিখবে না)।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Environments

> dev/staging/prod-এ পার্থক্য।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Defaults

> ডিফল্ট মান (secret ছাড়া)।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Secret handling

> secret কোথা থেকে আসবে (secrets-management.md)।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

