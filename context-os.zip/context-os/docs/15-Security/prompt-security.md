---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# Prompt Security

> prompt injection ও তথ্য ফাঁস প্রতিরোধ। AI না থাকলে not-applicable।

## Injection risks

> prompt injection-এর ঝুঁকি।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Input and output filtering

> ইনপুট-আউটপুট ছাঁকনি।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Data leakage rules

> ভেতরের তথ্য ফাঁস রোধ।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Tool-use limits

> AI কোন টুল চালাতে পারবে না।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

