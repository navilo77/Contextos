---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# Authentication

> লগইন, সেশন, পাসওয়ার্ড নীতি।

## Methods

> কোন পদ্ধতিতে লগইন।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Password and session rules

> পাসওয়ার্ড নীতি, সেশন।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Token lifetime

> মেয়াদ সংখ্যায়।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Account recovery

> পাসওয়ার্ড ভুলে গেলে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## MFA

> দ্বি-স্তর যাচাই আছে কি না।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

