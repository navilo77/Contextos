---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# Data Protection

> এনক্রিপশন, ব্যক্তিগত তথ্যের নিয়ম।

## Data classification

> কোন ডেটা কত স্পর্শকাতর।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Encryption

> যাত্রাপথে ও সংরক্ষণে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Retention and deletion

> কত দিন রাখা, মুছে ফেলার নিয়ম।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Personal data and consent

> সম্মতি ও ব্যক্তিগত তথ্য।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Legal and regional rules

> প্রযোজ্য আইন ও অঞ্চলের নিয়ম।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

