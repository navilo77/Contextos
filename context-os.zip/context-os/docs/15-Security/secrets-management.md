---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# Secrets Management

> key ও secret কোথায় থাকে।

## Secret types

> কী কী secret আছে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Storage

> কোথায় রাখা হবে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Rotation

> কত দিন পর বদল।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Never commit rules

> কোডে/রিপোজিটরিতে যা রাখা নিষেধ।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

