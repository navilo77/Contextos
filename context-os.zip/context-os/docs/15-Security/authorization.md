---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# Authorization

> কে কী করতে পারে (role/permission)।

## Roles

> role-এর তালিকা।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Permission matrix

> টেবিল: role × কাজ।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Enforcement points

> কোথায় যাচাই হয়।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Default policy

> ডিফল্টে সব নিষেধ।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

