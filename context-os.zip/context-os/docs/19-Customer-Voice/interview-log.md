---
status: draft
source: customer
applicable: true
updated: 2026-10-28
---
# Interview Log

> কাস্টমার যা বলেছে, হুবহু। এটাই `evidence`-এর উৎস।

| # | তারিখ | প্রশ্ন | কাস্টমারের উত্তর (হুবহু) | ব্যবহৃত ID |
|---|---|---|---|---|
| 1 | TODO | TODO | TODO | TODO |
