---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# User Flows

> ধাপে ধাপে ব্যবহারকারী কী করবে, কোন স্ক্রিনের পর কোনটা।

## Flow list

> FLOW-001... নাম ও সম্পর্কিত REQ।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Steps

> প্রতিটা flow: ধাপ | স্ক্রিন | ব্যবহারকারী কী করে | সিস্টেম কী করে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Error paths

> প্রতিটা ধাপে ভুল হলে কী হবে (error-catalog.md-এর কোড)।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Empty and loading states

> ডেটা না থাকলে বা লোড হওয়ার সময় কী দেখাবে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

