---
status: draft
source: customer
applicable: true
updated: 2026-10-28
---
# Personas

> কারা ব্যবহার করবে, তাদের লক্ষ্য ও সমস্যা।

## Personas

> প্রতিটা: নাম, লক্ষ্য, সমস্যা, প্রযুক্তি-দক্ষতা, ভাষা।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Primary and secondary

> কোনটা মূল ব্যবহারকারী।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Role mapping

> persona বনাম সিস্টেমের role (authorization.md-এর সাথে মিল)।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

