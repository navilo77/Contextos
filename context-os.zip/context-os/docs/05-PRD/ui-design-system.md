---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# UI Design System

> স্ক্রিনের চেহারার নিয়ম, যাতে কোডিং এজেন্ট রঙ-ফন্ট-লেআউট আন্দাজ না করে। (এজেন্ট-যোগ করা ফাইল)

## Brand and tone

> ব্র্যান্ডের ধরন, কণ্ঠস্বর, পছন্দের উদাহরণ (customer-voice থেকে)।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Colors

> নামসহ hex মান: primary, secondary, background, text, error, success।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Typography

> ফন্ট, আকার, বাংলা/ইংরেজি ফন্ট আলাদা হলে তা।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Components and framework

> কোন UI লাইব্রেরি/ক্লাস (যেমন Tailwind, MUI); বোতাম, ফর্ম, কার্ডের নিয়ম।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Layout and responsive rules

> মোবাইল/ডেস্কটপ ব্রেকপয়েন্ট, গ্রিড, ফাঁক।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Accessibility

> কনট্রাস্ট, ফন্ট-সাইজ, কীবোর্ড ব্যবহার।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

