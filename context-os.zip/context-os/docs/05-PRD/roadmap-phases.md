---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# Roadmap & Phases

> MVP-র পর কী কী ধাপে আসবে।

## Phase 1 (MVP)

> mvp-scope.md-এর সাথে মিল।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Phase 2

> পরের ধাপের ফিচার ও শর্ত।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Phase 3

> ভবিষ্যৎ।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Dependencies

> কোন ধাপ কোনটার উপর নির্ভর করে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

