---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# YAML Schema Spec

> রেকর্ড কীভাবে লিখতে হয় এবং validator কী যাচাই করে।

## প্রতিটা রেকর্ডে বাধ্যতামূলক
`id`, `title`, `status`, `source`, `confidence`, `links`, `updated`।

- `status`: `draft` | `confirmed` | `not-applicable` (সাথে `reason`)
- `source`: `customer` (কাস্টমার বলেছে, সাথে `evidence`) | `agent-assumed`
- `confirmed` হলে `approved_by` বাধ্যতামূলক
- `links`: `features`, `api`, `tests`, `tasks`, `requirements`: অন্য রেকর্ডের ID

## ID নিয়ম
`PREFIX-NNN`: REQ, FEAT, NFR, BR, API, EVAL, TASK, ARCH, DM, DEC, AGT, SOL। একটা ID একবারই।
ফাইলের নাম ID-র সমান হতে হবে (`REQ-001.yaml`)। একই ধরনের দুই রেকর্ডে একই `title` চলবে না।
`depends_on` ও `applies_to`-র ID বাস্তবে থাকতে হবে। TASK-এ চক্র (A→B→A) নিষেধ।
TASK-এর `progress`: `todo` | `in-progress` | `done`।
API রেকর্ডে `errors` (error-catalog.md-এর কোড) ও `rate_limit` বাধ্যতামূলক। data-model-এ `migrations` ও `seed_data` বাধ্যতামূলক।
প্রতিটা `.md` ফাইলের নির্ধারিত `## ` অংশ `04-Schemas/file-specs.yaml`-এ। খোলা `proposals/ESC-*.yaml` Gate আটকায়।

## SSoT Sync কী মেলায়
`02-SSoT/ssot.data.yaml`-এর `index`-এ প্রতিটা ID-র `title`, `status`, `source` ফাইলের সাথে হুবহু মিলতে হবে।
`updated` ssot-এ নতুন হলে ফাইল "পুরনো" ধরা হয়।

## Gate শর্ত
schema ত্রুটি, ডুপ্লিকেট, ভাঙা লিংক, পুরনো ফাইল, TODO বাকি ফাইল, খোলা blocking প্রশ্ন, AI-ধরা high বিরোধ সব ০; সব must-have REQ confirmed; SSoT Sync ১০০%; `reports/ai-consistency.yaml`-এ `checked` তারিখ ও সংখ্যা; manifest/ssot-এ প্রজেক্টের নাম ভরা; স্কোর ≥ ৯০।

## Markdown ফাইল
শুরুতে frontmatter: `status`, `source`, `applicable`, `updated`। `TODO` শব্দ থাকলে ফাইল অসম্পূর্ণ ধরা হয়।

## প্রতিটা schema-র কাঠামো
`required` (অতিরিক্ত ফিল্ড), `enums` (অনুমোদিত মান), `prefix` (ID-র শুরু)।
