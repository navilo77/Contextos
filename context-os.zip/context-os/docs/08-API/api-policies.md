---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# API Policies

> সব API-র সাধারণ নীতি (rate limit, pagination, ইত্যাদি)। (এজেন্ট-যোগ করা ফাইল)

## Versioning

> API সংস্করণ কীভাবে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Pagination, filtering, sorting

> সংখ্যা সহ নিয়ম (পেজ-সাইজ, সর্বোচ্চ)।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Rate limiting

> কোন endpoint-এ কত অনুরোধ, কত সময়ে; সীমা পেরোলে কী উত্তর।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Idempotency

> দুবার অনুরোধ এলে কী হবে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Timeouts and retries

> সময়সীমা ও পুনঃচেষ্টা।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Auth conventions

> হেডার/টোকেনের নিয়ম।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

