---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# Error Catalog

> সব ত্রুটি ও বার্তার একটাই তালিকা, যাতে এজেন্ট বার্তা বানিয়ে না ফেলে। (এজেন্ট-যোগ করা ফাইল)

## Error format

> সব API-র ত্রুটির একই কাঠামো (JSON ক্ষেত্র)।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Error codes

> টেবিল: কোড | HTTP স্ট্যাটাস | ব্যবহারকারীকে বার্তা | ডেভেলপারের জন্য ব্যাখ্যা।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Message language

> বার্তা কোন ভাষায়, কোথায় থেকে আসে (i18n-localization.md)।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Logging of errors

> কোন ত্রুটি লগ হবে (logging-standards.md)।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

