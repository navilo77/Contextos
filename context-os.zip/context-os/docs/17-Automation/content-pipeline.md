---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# Content Pipeline

> কনটেন্ট তৈরি থেকে প্রকাশ পর্যন্ত ধাপ।

## Stages

> ধাপ: ধারণা থেকে প্রকাশ।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Owners

> কে কোন ধাপে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Approval gate

> কোথায় অনুমোদন।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Publishing channels

> কোথায় প্রকাশ।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

