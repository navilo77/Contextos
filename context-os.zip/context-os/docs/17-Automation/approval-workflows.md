---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# Approval Workflows

> কোথায় মানুষের অনুমোদন লাগবে।

## Items needing approval

> কী কী।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Approvers

> কে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Timeouts

> সাড়া না দিলে কী।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Audit

> রেকর্ড।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

