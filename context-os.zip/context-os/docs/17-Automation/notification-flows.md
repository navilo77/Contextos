---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# Notification Flows

> কখন কাকে কী বার্তা যাবে।

## Events

> কোন ঘটনায় বার্তা।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Channels

> SMS, ইমেইল, WhatsApp ইত্যাদি।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Templates

> বার্তার ছাঁচ।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Frequency limits

> কত ঘন ঘন।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Opt-out

> বন্ধ করার নিয়ম।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

