---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# n8n Workflows

> n8n (বা অন্য টুলে) স্বয়ংক্রিয় workflow।

## Workflow list

> টেবিল: WF-id | ট্রিগার | ধাপ | মালিক।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Credentials

> কোন সংযোগ লাগে (নাম মাত্র)।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Error handling

> ব্যর্থ হলে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Versioning

> export ও ইতিহাস রাখার নিয়ম।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

