---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# Marketing Automation

> মার্কেটিংয়ের স্বয়ংক্রিয় কাজ।

## Triggers

> কোন ঘটনায় কী চলবে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Audience rules

> কারা পাবে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Content approval

> কে অনুমোদন করে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Opt-out

> বন্ধ করার নিয়ম।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

