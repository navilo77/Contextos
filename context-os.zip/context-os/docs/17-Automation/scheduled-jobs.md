---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# Scheduled Jobs

> নির্দিষ্ট সময়ের কাজ।

## Job list

> টেবিল: নাম | সময়সূচি | উদ্দেশ্য।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Failure handling

> ব্যর্থ হলে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Idempotency

> দুবার চললে কী হবে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

