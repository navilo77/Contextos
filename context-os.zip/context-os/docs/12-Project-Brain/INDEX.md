---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# Project Brain Index

> এজেন্টের পড়ার ক্রম ও কোন ফোল্ডারে কী আছে।

1. `00-Foundation/vision.md`, `mvp-scope.md`, `non-goals.md`
2. `02-SSoT/ssot.summary.md`
3. `05-PRD/` (requirements → features)
4. `06-SAD`, `07-Database`, `08-API`
5. `10-Implementation/`
6. `20-Tasks/`: এখান থেকে কাজ শুরু

বিশেষ ফাইল: `05-PRD/ui-design-system.md`, `06-SAD/frontend-state.md`, `07-Database/migrations-and-seed.md`, `08-API/error-catalog.md` ও `api-policies.md`, `09-Validation/test-data.md`, `10-Implementation/local-setup.md`, `i18n-localization.md`, `logging-standards.md`, `16-Integrations/webhook-handling.md`।

মডিউল ফোল্ডার (`13`–`18`) শুধু `manifest.yaml`-এ চালু থাকলে প্রযোজ্য। বন্ধ থাকলে validator বাদ দেয়।

TODO: প্রজেক্ট-নির্দিষ্ট নোট যোগ করো।
