---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# Incident Response

> সমস্যা হলে কে কী করবে।

## Severity levels

> মাত্রা ও সংজ্ঞা।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Roles

> কে কী করবে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Steps

> সমস্যা হলে ধাপে ধাপে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Communication

> কাকে কীভাবে জানানো হবে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Post-mortem

> ঘটনার পর পর্যালোচনা।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

