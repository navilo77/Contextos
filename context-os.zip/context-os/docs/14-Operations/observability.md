---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# Observability

> লগ, ট্রেস ও মেট্রিক সংগ্রহ।

## Log pipeline

> লগ কোথায় যায়।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Metrics pipeline

> মেট্রিক কোথায় যায়।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Tracing

> ট্রেসিং আছে কি না।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Dashboards

> কোন ড্যাশবোর্ড।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

