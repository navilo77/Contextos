---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# Deployment

> পরিবেশ, CI/CD, rollback।

## Environments

> dev, staging, production।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Release steps

> ধাপে ধাপে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Rollback

> ফেরত নেওয়ার উপায়।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Config per environment

> প্রতিটা পরিবেশে কী আলাদা।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Downtime policy

> বন্ধ রাখার নিয়ম।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

