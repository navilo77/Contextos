# ADR-NNN: শিরোনাম

- তারিখ:
- সিদ্ধান্তদাতা (approved_by):
- অবস্থা: proposed | accepted | superseded

## প্রসঙ্গ

## বিকল্প

## সিদ্ধান্ত

## ফলাফল
