---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# Decisions Log

> চূড়ান্ত সিদ্ধান্তের সূচি (DEC ID সহ)। এজেন্ট এগুলো বদলাবে না।

## Decision index

> টেবিল: DEC-ID | শিরোনাম | তারিখ | অবস্থা।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Superseded decisions

> বাতিল বা প্রতিস্থাপিত সিদ্ধান্ত ও কারণ।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

