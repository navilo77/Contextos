---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# Migrations & Seed Data

> ডাটাবেস বদল ও প্রাথমিক ডেটার নিয়ম। (এজেন্ট-যোগ করা ফাইল)

## Migration tool

> কোন টুল, কীভাবে চালানো হয়।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Naming and order

> migration ফাইলের নাম ও ক্রম।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Rollback policy

> ফেরত নেওয়ার নিয়ম।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Seed data

> প্রাথমিক ডেটা কী কী, কোথা থেকে আসে, কখন ঢোকে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Environment separation

> dev/test/prod-এ কোন ডেটা কোথায়।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

