---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# Test Strategy

> কী কীভাবে পরীক্ষা হবে: unit, integration, e2e।

## Test levels

> unit, integration, e2e: কোনটা কোথায়।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Tools

> কোন টেস্ট টুল।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Coverage targets

> সংখ্যায় লক্ষ্য।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Environments

> কোথায় চলবে, CI গেট।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

