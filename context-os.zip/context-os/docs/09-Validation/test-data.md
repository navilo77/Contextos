---
status: draft
source: agent-assumed
applicable: true
updated: 2026-10-28
---
# Test Data Management

> টেস্টের ডেটা, মক ও রিসেটের নিয়ম। (এজেন্ট-যোগ করা ফাইল)

## Data source

> টেস্ট ডেটা কোথা থেকে (fixtures, factories, seed)।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Reset policy

> প্রতি টেস্টের আগে/পরে ডাটাবেস কীভাবে রিসেট।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Mocks and stubs

> বাইরের সার্ভিস কীভাবে নকল হবে।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

## Sensitive data rule

> আসল গ্রাহকের তথ্য টেস্টে নিষেধ।

TODO: লিখুন। জানা না থাকলে আন্দাজ নয়, `11-Decisions/open-questions.yaml`-এ প্রশ্ন।

